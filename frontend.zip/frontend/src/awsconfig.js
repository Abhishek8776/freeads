const awsconfig = {
    aws_project_region: "your-region",
    aws_cognito_identity_pool_id: "your-identity-pool-id",
    aws_cognito_region: "your-region",
    aws_user_pools_id: "your-user-pool-id",
    aws_user_pools_web_client_id: "your-app-client-id",
    aws_s3_bucket: "your-s3-bucket-name",
    aws_s3_bucket_region: "your-s3-region",
  };
  
  export default awsconfig;
  